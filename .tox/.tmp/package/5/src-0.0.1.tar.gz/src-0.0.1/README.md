create environment

activate the env

install the dependencies
